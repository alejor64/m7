---
order: 10
title:
  zh-CN: 密码框
  en-US: Password box
---

## zh-CN

密码框，版本 3.12.0 中新增。

## en-US

Input type of password and added in 3.12.0.

```jsx
import { Input } from 'antd';

ReactDOM.render(<Input.Password placeholder="input password" />, mountNode);
```

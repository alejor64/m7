---
order: 1
title:
  zh-CN: 复杂的组合
  en-US: Complex combination
---

## zh-CN

更复杂的组合。

## en-US

Complex combination with avatar and multiple paragraphs.

```jsx
import { Skeleton } from 'antd';

ReactDOM.render(<Skeleton avatar paragraph={{ rows: 4 }} />, mountNode);
```

---
order: 2
title:
  zh-CN: 动画效果
  en-US: Active Animation
---

## zh-CN

显示动画效果。

## en-US

Display active animation.

```jsx
import { Skeleton } from 'antd';

ReactDOM.render(<Skeleton active />, mountNode);
```

---
order: 1
title:
  zh-CN: 更多
  en-US: More
---

## zh-CN

更多分页。

## en-US

More pages.

```jsx
import { Pagination } from 'antd';

ReactDOM.render(<Pagination defaultCurrent={6} total={500} />, mountNode);
```
